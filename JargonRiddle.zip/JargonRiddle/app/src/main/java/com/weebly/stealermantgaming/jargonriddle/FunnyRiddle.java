package com.weebly.stealermantgaming.jargonriddle;

import android.support.annotation.NonNull;

public class FunnyRiddle
{
	private final String question;
	private final String answer;
	private String imageFile;
	
	public FunnyRiddle(String q, String a)
	{
		question = q;
		answer = a;
	}

	public FunnyRiddle(String q, String a, String i)
    {
        this(q,a);
        imageFile = i;
    }
	
	public String getQuestion()
	{
		return question;
	}
	
	public String getAnswer()
	{
		return answer;
	}

	public String getImageFile() { return imageFile;}
	
	public boolean isRight(String response)
	{
		return answer.equalsIgnoreCase(response);
	}
	
	@NonNull
	public String toString()
	{
		return question + " " + answer;
	}
}