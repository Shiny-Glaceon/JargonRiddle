package com.weebly.stealermantgaming.jargonriddle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Arrays;

public class RiddleActivity extends AppCompatActivity {

    private TextView mRiddleView;
    private TextView mPointView;
    private TextView mSubmitText;
    private TextView mHealthView;
    private int health;
    private int points;
    private int numQuestions;
    private int questionIndex;
    private boolean ansCorrect;
    //private RiddlePack gayboy21;
    private String[] questions = {"What's in a man's pants that you won't find in a woman's pants?", "What's a four-letter word that ends in 'k' and means the same as intercourse?", "What is hairy on the outside but soft and wet on the inside and whose word starts with the letter 'c'", "What's at least 4 inches long, goes in your mouth, and is more fun if it vibrates?", "What goes up, lets out a load, and then goes back down?", "When I go in, I can cause some pain. I'll fill your holes when you ask me to. I also that you spit, and not swallow. What am I?", "What does every woman have that starts with a \"V\" and that she can use to get what she wants?", "What does a cow have four of that a woman only has two of?", "Every man has one. Some are big, some are small. It feels great when you blow it, but it drips if you aren't careful. What is it?", "Some people prefer being on top, others prefer being on the bottom, and it always involves a bed. What is it?", "What starts with \"p\" and ends with \"orn\" and is the hottest part of the movie industry?"};
    private String[] answers = {"pockets", "talk", "coconut", "toothbrush", "elevator", "dentist", "voice", "legs", "nose", "bunk bed", "popcorn"};

    private void checkAnswer()
    {
        int messageResId;
        //boolean check = gayboy21.getRiddle(questionIndex).isRight("" + mSubmitText.getText());

        String bob = answers[questionIndex];

        boolean check = bob.equalsIgnoreCase(""+mSubmitText.getText());

        if(check)
        {
            questionIndex++;
            points += 10;
            messageResId = R.string.correct_toast;
            ansCorrect = true;
        }
        else{
            points -= 5;
            health -= 10;
            messageResId = R.string.incorrect_toast;
            ansCorrect = false;
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();

        update();
    }

    private void getHint()
    {
        int messageResId = R.string.hint_toast;
        Toast.makeText(this, messageResId, Toast.LENGTH_LONG).show();
    }

    private void giveUp() throws InterruptedException {
        int messageResId = R.string.give_up;
        Toast.makeText(this, messageResId, Toast.LENGTH_LONG).show();

        wait(3000);

        while(health != 0)
        {
            health -= 10;
            mHealthView.setText(health);
            wait(500);
        }

        questionIndex = 0;
        updateQuestion();

        points = 0;
        mPointView.setText("Points: 0");
    }

    private void updateQuestion()
    {
        //mRiddleView.setText(gayboy21.getRiddle(questionIndex).getQuestion());
        mRiddleView.setText(questions[questionIndex]);
    }

    private void update()
    {
        String a = "Points: ";
        String b = "Health: ";
        mPointView.setText(a + points);
        mHealthView.setText(b + health);

        if(ansCorrect) {
            if (!checkWin())
                updateQuestion();
            else if (checkWin()) {
                int messageResId = R.string.win;
                Toast.makeText(this, messageResId, Toast.LENGTH_LONG).show();
            }
        }

        if(health == 0)
        {
            int messageResId = R.string.lose;
            Toast.makeText(this, messageResId, Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riddle);

        //gayboy21 = new RiddlePack("InnuendoRiddles.dat");
        Button giveUpButton = findViewById(R.id.giveUpButton);
        Button submitButton = findViewById(R.id.submitButton);
        mRiddleView = findViewById(R.id.riddleView);
        mPointView = findViewById(R.id.pointView);
        mSubmitText = findViewById(R.id.answerText);
        mHealthView = findViewById(R.id.healthView);
        TextView hintButton = findViewById(R.id.hintButton);

        health = 100;
        points = 0;
        //numQuestions = gayboy21.getNumberOfQuestions();

        numQuestions = questions.length;

        questionIndex = 0;
        ansCorrect = false;

        //mRiddleView.setText(gayboy21.getRiddle(questionIndex).getQuestion());

        mRiddleView.setText(questions[questionIndex]);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                checkAnswer();
            }
        });

        hintButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                getHint();
            }
        });

        giveUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    giveUp();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public int getNumQuestions()
    {
        return numQuestions;
    }

    private boolean checkWin()
    {
        return numQuestions - 1 == questionIndex;
    }
}
