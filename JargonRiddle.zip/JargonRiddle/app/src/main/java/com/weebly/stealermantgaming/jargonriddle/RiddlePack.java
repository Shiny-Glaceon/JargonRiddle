package com.weebly.stealermantgaming.jargonriddle;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
import java.io.File;
import java.io.IOException;

public class RiddlePack
{
	private ArrayList<FunnyRiddle> pack;
	
	public RiddlePack()
	{
		pack = new ArrayList<FunnyRiddle>();
	}
	
	public RiddlePack(String file) 
	{
		pack = new ArrayList<FunnyRiddle>();
		try
		{
			Scanner f = new Scanner(new File(file));
			String line;
			int max = f.nextInt();
			f.nextLine();
			for(int k = 0; k < max; k++)
			{
				line = f.nextLine();
				int divide = line.indexOf("|");
				int lastDivide = line.lastIndexOf("|");
				String q = line.substring(0,divide);
				String a;
				String i;
				if(divide != lastDivide)
				{
					a = line.substring(divide+1,lastDivide);
					i = line.substring(lastDivide+1,line.length());
					pack.add(new FunnyRiddle(q,a,i));
				}
				else
				{
					a = line.substring(divide+1,line.length());
					pack.add(new FunnyRiddle(q,a));
				}
				
			}
		}
		catch (Exception e)
		{
		}
	}
	
	
	
	public boolean addRiddle(String question, String answer)
	{
		return pack.add(new FunnyRiddle(question,answer));
	}
	
	public void addRiddle(int index, String question, String answer)
	{
		pack.add(index, new FunnyRiddle(question,answer));
	}
	
	public void setRiddle(int index, String question, String answer)
	{
		pack.set(index, new FunnyRiddle(question,answer));
	}
	
	public FunnyRiddle removeRiddle(int index)
	{
		return pack.remove(index);
	}		
	
	public FunnyRiddle getRiddle(int index)
	{
		return pack.get(index);
	}
	
	public String getQuestion(int index)
	{
		return pack.get(index).getQuestion();
	}
	
	public String getAnswer(int index)
	{
		return pack.get(index).getAnswer();
	}
	
	public boolean checkAnswer(int index, String response)
	{
		return pack.get(index).isRight(response);
	}
	
	public void swapRiddles(int one, int two)
	{
		FunnyRiddle t = pack.get(one);
		pack.set(one, pack.get(two));
		pack.set(two, t);
	}
	
	public int getNumberOfQuestions()
	{
		return pack.size();
	}
	
	public void scramblePack()
	{
		Collections.shuffle(pack);
	}
	
	public String toString()
	{
		return "" + pack;
	}
}